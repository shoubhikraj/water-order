#include <string>

static thread_local std::string FOOBAR = "";

int main() {
    return 0;
}
