.. _class-UnitCell:

UnitCell
========

.. doxygenclass:: chemfiles::UnitCell
    :members:
