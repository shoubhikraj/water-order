.. _class-Trajectory:

Trajectory
==========

.. doxygenclass:: chemfiles::Trajectory
    :members:
