.. _class-Residue:

Residue
=======

.. doxygenclass:: chemfiles::Residue
    :members:
