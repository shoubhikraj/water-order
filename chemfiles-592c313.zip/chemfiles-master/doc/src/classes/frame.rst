.. _class-Frame:

Frame
=====

.. doxygenclass:: chemfiles::Frame
    :members:
