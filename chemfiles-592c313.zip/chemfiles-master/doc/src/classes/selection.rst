.. _class-Selection:

Selection
=========

.. doxygenclass:: chemfiles::Selection
    :members:

.. doxygenclass:: chemfiles::Match
    :members:
