.. _class-Atom:

Atom
====

.. doxygenclass:: chemfiles::Atom
    :members:
