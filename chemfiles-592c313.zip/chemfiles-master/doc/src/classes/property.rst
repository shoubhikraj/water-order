.. _class-Property:

Property
========

.. doxygenclass:: chemfiles::Property
    :members:
